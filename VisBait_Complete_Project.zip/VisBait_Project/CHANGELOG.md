# VisBait Changelog

## v1.0.0 — Web App Launch (In Progress)

### Features Added
- Feed tab: weather card, stories, live news badge, post cards with like/dislike
- Reels tab: full-screen TikTok-style vertical scroll, comments sheet
- Discover tab: Threads (upvote/downvote), Market with proximity filter, Map with Google Maps
- 4-step Create Listing wizard (gear, boats, bulk bundles)
- Post button: Photo / Reel / Story upload modal
- Profile tab: Posts / Reels / Catches / Achievements grids
- Trophy Room: XP bar, gold/silver/bronze achievements, proof post links
- Leaderboard panel: Points / Count / Rare tabs with ranking
- Messages panel: DMs + Group chats
- Edit Profile modal: Info / Photo / Achievements pin selector / Prefs
- Earnable statuses: Tournament Pro (apply) + Achievement Hunter (auto)
- Location permission splash with real geolocation + reverse geocoding
- Achievement display: pin up to 3 to public profile

### App Details
- Single-file architecture (index.html)
- No external framework dependencies
- Google Maps JavaScript API integration
- Supabase-ready database structure
- PWA-ready (manifest.json + service worker)
