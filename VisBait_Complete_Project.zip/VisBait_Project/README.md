# 🎣 VisBait — Fishing Social App

A full-featured fishing social media platform built as a single HTML web app.

## 🚀 Quick Start

### Option 1 — Open Locally
Just open `index.html` in any browser. Everything runs client-side.

### Option 2 — Deploy to GitHub Pages (Recommended)
1. Create a new GitHub repository named `visbait`
2. Upload `index.html` to the repo root
3. Go to Settings → Pages → Source: main branch
4. Your app is live at `https://yourusername.github.io/visbait`

### Option 3 — Connect Your Domain
1. Buy `visbait.com` on Namecheap (~$14/yr)
2. Create a free Cloudflare account
3. Add CNAME record: www → yourusername.github.io
4. Enable HTTPS in Cloudflare → SSL/TLS → Full (Strict)

---

## 📱 Features

### 🏠 Feed Tab
- Live weather card with 7-day forecast and fishing conditions rating
- Stories row
- Live news badge with posts (like/dislike reactions)
- News, catch, and tip post cards

### 🎬 Reels Tab
- Full-screen TikTok-style vertical scroll feed
- Like / dislike / comment / share on each reel
- Follow/unfollow authors
- Bottom sheet comments with reply support

### 🧭 Discover Tab
- **Threads** — Reddit-style upvote/downvote forum
- **Market** — Tackle Shop with proximity filter (5mi → Anywhere)
  - 4-step Create Listing wizard
  - Boat listings with dedicated fields (year, length, HP, hours)
  - Bundle/bulk item builder
  - Stripe-ready pricing types (Fixed/OBO/Free/Auction)
- **Map** — Google Maps powered community fishing spots
  - Drop pins on real map (click to add)
  - Spot cards with like/dislike reactions

### 📸 Post Button (center tab)
- Upload Photo, Reel/Video, or Story
- Caption, tags, location, species fields

### 👤 Profile Tab
- Achievement count badge next to name
- Posts / Reels / Catches / Achievements grids
- Trophy Room with XP progress bar
- Gold/Silver/Bronze achievement tiers with proof post links
- Locked achievements with progress bars

### ✏️ Edit Profile Modal (4 tabs)
- **Info** — Name, handle, bio, location, fishing style
- **Earnable Status** — Tournament Pro (apply) + Achievement Hunter (auto-tracked)
- **Photo** — Avatar picker + cover theme swatches
- **Achievements** — Pin up to 3 achievements to public profile (tap to pin/unpin)
- **Prefs** — Privacy toggles, measurement units

### 🏅 Leaderboard (top nav)
- Three tabs: Points (XP) / Count (achievements) / Rare
- Your rank highlighted
- Status icons for Tournament Pro (🏆) and Achievement Hunter (🎯)

### 💬 Messages (top nav)
- Direct messages + group chats
- Real-time auto-reply simulation
- Group creation with emoji + color picker

### 📍 Location Permission
- Full-screen splash on first load
- Browser geolocation API
- Reverse geocode via OpenStreetMap Nominatim
- Updates weather location + map center

---

## 🗺️ API Keys (Replace Before Launch)

| Service | Location in code | How to get |
|---------|-----------------|------------|
| Google Maps | `AIzaSyAhnozpgvCllW-FJrCWktLSSeG9aNMqVp0` | console.cloud.google.com |

**Important:** Before going live, restrict your Google Maps key to `visbait.com/*` only in Google Cloud Console.

---

## 🔒 Security Checklist (Do Before Public Launch)

- [ ] Restrict Google Maps API key to your domain
- [ ] Add Cloudflare security headers (CSP, X-Frame-Options, etc.)
- [ ] Enable Cloudflare rate limiting
- [ ] Run OWASP ZAP security scan
- [ ] Add Privacy Policy + Terms of Service (Termly.io)
- [ ] Add COPPA age gate (13+) to signup
- [ ] Add cookie consent banner
- [ ] Connect Supabase for real user authentication

---

## 🛠️ Next Development Steps

1. **Add Supabase backend** (supabase.com — free)
   - User auth (email + Google login)
   - Real posts, catches, map pins stored in database
   - Real-time messages

2. **Add real image uploads**
   - Supabase Storage (1GB free)
   - Connect to post/reel upload form

3. **Add real weather**
   - OpenWeatherMap API (free, 1,000 calls/day)
   - Replace hardcoded weather card data

4. **Add Stripe payments**
   - VisBait Pro — $7.99/month
   - VisBait Elite — $14.99/month
   - Marketplace transaction fee (6%)

5. **Convert to PWA**
   - Add manifest.json + service worker
   - Users can install on phone home screen

---

## 📁 Project Files

| File | Description |
|------|-------------|
| `index.html` | Complete VisBait web app (all-in-one) |
| `VisBait_Launch_Roadmap.xlsx` | Full business + legal roadmap with June deadline |
| `README.md` | This file |

---

## 🏢 Business Info

- **Company:** VisBait LLC (to be formed in Philadelphia, PA)
- **Filing:** file.dos.pa.gov → Certificate of Organization → $125
- **Trademark:** USPTO Class 35 + 42 (file at uspto.gov)
- **Legal Docs:** Generate at termly.io, then have attorney review
- **Banking:** Mercury (mercury.com) — free business banking

---

## 📞 Key Contacts & Links

- PA LLC filing: file.dos.pa.gov
- IRS EIN (free): irs.gov EIN online application
- USPTO trademark: tmsearch.uspto.gov (search), uspto.gov (file)
- Philadelphia Bar Referral: 215-238-6333
- Next Insurance: next.com

---

*Built with HTML, CSS, and vanilla JavaScript. No frameworks required.*
