# Security Policy — VisBait

## Supported Versions

| Version | Supported |
|---------|-----------|
| Latest  | ✅ |

## Reporting a Vulnerability

If you discover a security vulnerability in VisBait, please report it responsibly:

1. **Do NOT** open a public GitHub issue
2. Email: security@visbait.com
3. Include: description, reproduction steps, potential impact
4. We will acknowledge within 48 hours and aim to resolve within 14 days

## Security Measures

- HTTPS enforced via Cloudflare (SSL/TLS Full Strict)
- Security headers: CSP, X-Frame-Options, HSTS
- Rate limiting via Cloudflare WAF
- Google Maps API key restricted to visbait.com domain
- User inputs sanitized before display (XSS prevention)
- OWASP ZAP scans run monthly
- COPPA compliant — age gate at 13+
- GDPR/CCPA compliant — privacy policy, consent banner, data deletion

## NIST Compliance

This application follows NIST SP 800-53 guidelines including:
- AC: Access control via Supabase Row Level Security
- AU: Audit logging via Cloudflare and Supabase logs
- IA: Identity and authentication via Supabase Auth
- SC: System and communications protection via HTTPS/TLS
- SI: Input validation and sanitization on all user fields
